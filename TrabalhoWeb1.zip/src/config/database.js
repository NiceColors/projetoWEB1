module.exports = { //Exportando configuração do banco de dados
    dialect: 'mysql', //Sistema de gerenciamento de banco de dados
    host: 'localhost', 
    username: 'root',
    password: '1234',
    database: 'web1db', //Nome da DB
}